# 라이브러리 import

import selenium
from selenium import webdriver                            # webdriver: 웹 브라우저를 제어하기 위한 모듈
from selenium.webdriver.chrome.service import Service     # Service: 드라이버 서비스를 관리하기 위한 클래스
from webdriver_manager.chrome import ChromeDriverManager  # ChromeDriverManager: ChromeDriver를 자동으로 다운로드하고 경로를 설정하는 클래스
from selenium.webdriver.common.keys import Keys           # Keys: 키보드 키를 시뮬레이션하는 데 사용하는 클래스
from selenium.webdriver.common.by import By               # By: WebElement를 찾을 때 사용하는 메소드를 포함하는 클래스
import time                                               # time: 시간 관련 함수를 제공하는 모듈
import os                                                 # os: 운영 체제와 상호 작용하기 위한 다양한 함수를 제공하는 모듈
import urllib.request                                     # urllib.request: URL을 열고 읽기 위한 라이브러리

search = input("이미지 검색====>")  # 사용자로부터 이미지 검색어를 입력 받음
fileName = 'image'                 # 저장할 이미지의 기본 이름
number = 100                       # 다운로드할 이미지의 수
interval = 0.2                     # 작업 간의 시간 간격

# Chrome WebDriver 설정 및 초기화
service = Service(executable_path=ChromeDriverManager().install())
driver = webdriver.Chrome(service=service)

# 구글 이미지 검색 페이지로 이동
driver.get(f"https://www.google.com/search?sca_esv=587728493&q={search}&tbm=isch&source=lnms&sa=X&ved=2ahUKEwiCzZrDpvaCAxWf2DQHHZwsA2cQ0pQJegQIDxAB&biw=1536&bih=715&dpr=1.25")

# 첫 번째 이미지를 찾아서 클릭함
firstImage = driver.find_element(By.XPATH,"/html/body/div[2]/c-wiz/div[3]/div[1]/div/div/div/div/div[1]/div[1]/span/div[1]/div[1]/div[1]/a[1]/div[1]/img")
firstImage.click()
# 지정된 숫자만큼 이미지를 다운로드하는 루프
for i in range(number):
    try:
        time.sleep(interval) # 지정된 시간만큼 대기
        # 이미지 요소를 찾아 'src' 속성(이미지 URL)을 얻음
        image = driver.find_element(By.CSS_SELECTOR, "#Sva75c > div.A8mJGd.NDuZHe.CMiV2d.OGftbe-N7Eqid-H9tDt > div.dFMRD > div.AQyBn > div.tvh9oe.BIB1wf.hVa2Fd > c-wiz > div > div > div > div > div.v6bUne > div.p7sI2.PUxBg > a > img.sFlh5c.pT0Scc.iPVvYb")
        imageSrc = image.get_attribute('src')

        # 'img' 디렉터리가 존재하지 않으면 생성
        if not os.path.exists('img'):
            os.makedirs('img')

        # 이미지를 다운로드하여 'img' 디렉터리에 번호를 붙여 저장
        urllib.request.urlretrieve(imageSrc, f'img/{fileName}_{i+1}.jpg') # urlretrieve함수: 웹상에 자료를 다운로드 할수 있게 도와주는 함수
    except:   # 오류 발생
        print(f'{i+1}번째 이미지 다운로드 실패') # 다운로드 중 오류가 발생하면 오류 메시지를 출력
    else:     # 오류가 없을 경우에만 수행        
        print(f'{i+1}번째 이미지 다운로드 성공')  # 다운로드가 성공적이면 성공 메시지를 출력
    finally:  # 예외 발생 여부 상관없이 항상 수행
        # 다음 이미지로 넘어가기 위해 다음 버튼을 클릭
        nextButton = driver.find_element(By.CSS_SELECTOR, "#Sva75c > div.A8mJGd.NDuZHe.CMiV2d.OGftbe-N7Eqid-H9tDt > div.dFMRD > div.AQyBn > div.tvh9oe.BIB1wf.hVa2Fd > c-wiz > div > div > div > div > div.s9n5ef.dZ5aUe > div > div.vbLSne > button:nth-child(2)")
        nextButton.click()
        
# 모든 작업이 완료된 후 WebDriver를 종료
driver.quit()



